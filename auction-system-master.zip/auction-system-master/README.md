
### Install
Install MySQL server locally, then run the scripts to setup:
```sh
$ cd server/ && ./db-create.sh
$ ./db-init.sh
$ ./db-setup.sh
```
Install project dependencies
```sh
$ npm install
```
### Run
Then start the project
```sh
$ npm start
```

Open on your browser:
http://localhost:3000/
